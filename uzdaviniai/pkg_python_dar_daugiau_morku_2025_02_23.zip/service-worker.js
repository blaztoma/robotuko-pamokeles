/**
 * Copyright 2016 Google Inc. All rights reserved.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
*/

// DO NOT EDIT THIS GENERATED OUTPUT DIRECTLY!
// This file should be overwritten as part of your build process.
// If you need to extend the behavior of the generated service worker, the best approach is to write
// additional code and include it using the importScripts option:
//   https://github.com/GoogleChrome/sw-precache#importscripts-arraystring
//
// Alternatively, it's possible to make changes to the underlying template file and then use that as the
// new base for generating output, via the templateFilePath option:
//   https://github.com/GoogleChrome/sw-precache#templatefilepath-string
//
// If you go that route, make sure that whenever you update your sw-precache dependency, you reconcile any
// changes made to this original template file with your modified copy.

// This generated service worker JavaScript will precache your site's resources.
// The code needs to be saved in a .js file at the top-level of your site, and registered
// from your pages in order to be used. See
// https://github.com/googlechrome/sw-precache/blob/master/demo/app/js/service-worker-registration.js
// for an example of how you can register this script and handle various service worker events.

/* eslint-env worker, serviceworker */
/* eslint-disable indent, no-unused-vars, no-multiple-empty-lines, max-nested-callbacks, space-before-function-paren, quotes, comma-spacing */
'use strict';

var precacheConfig = [["adlcp_rootv1p2.xsd","d574ff030bbb0217dfab6a9c0e7a7795"],["favicon.ico","36f3405c5c301c308b0b84fa526ea210"],["ims_xml.xsd","4f550f4771e8b40270c49947d1b19142"],["imscp_rootv1p1p2.xsd","ee6cf8dbdd91e8fdbb6b1aade679a315"],["imslrm.xml","888b6bca7ff5d595f90352f3782571f3"],["imsmanifest.xml","c48d9d6e829645af6ba3885c851e027b"],["imsmd_rootv1p2p1.xsd","5930c9d69201ba90900e759e2f8324bc"],["index.html","7e773bd0ac6f269f943659ae4afb1cb8"],["javascript/SCOFunctions.js","1a7c892fc336e9e5b78a70d60e9c6a57"],["javascript/SCORM_API_wrapper.js","8b91f9d3f08b25fb70e8736cbf02cab4"],["javascript/acorn_interpreter.js","3ec00171a43fc4221e37f3334bcb143c"],["javascript/blockly_compressed.js","59e1ce5378043bddd88120fef607ab0f"],["javascript/blockly_msg/cn.js","793f1344bc99fb00ff3604c96d727976"],["javascript/blockly_msg/de.js","142fde92da015346e48655eaa21df450"],["javascript/blockly_msg/en.js","a814a253b90069f9712012bea95b2f56"],["javascript/blockly_msg/fr.js","f373c7e5eb15b83517db440709b3382b"],["javascript/blockly_msg/ko.js","46df9f170caedf467df46839bff46ec2"],["javascript/blockly_msg/lt.js","3f2a2acb75c3b994ba95dd01ee5b6232"],["javascript/blockly_msg/pl.js","3715d8ae55daf3a9a96d95689212666b"],["javascript/blocks_compressed.js","ccbd4d09af25d28e5b1d36c443542ff4"],["javascript/codemirror.js","489dea083138c40e7c608aa99a3b6527"],["javascript/coffeescript.js","24d60b6f63de3753d4cec219c96062b0"],["javascript/diff_match_patch_uncompressed.js","2030474dfca187e4cad49ee5585985ef"],["javascript/filesaver.js","18acc5d2fbda327a930dda05598dedcd"],["javascript/javascript_compressed.js","cd9ad780a5f3a778c0504adc07fdfb8f"],["javascript/jquery-ui.min.js","640347581be624cd990a11ede22580c4"],["javascript/jquery.min.js","1514be1acf771d5a484aeed96b2d30ba"],["javascript/language.js","e2d1ba21e2dda46d27aff9d1827db137"],["javascript/mode/css/css.js","c88b0eb0c43e106943827b6fc3886288"],["javascript/mode/css/gss.html","f984d854a1b531d10f33ba77417222bb"],["javascript/mode/css/gss_test.js","28e904088454a38b89cda0b3f9712172"],["javascript/mode/css/index.html","c5494a886b36ff6e45afc07e71650b75"],["javascript/mode/css/less.html","ab02b2ae472dcd4db340cef9789c865d"],["javascript/mode/css/less_test.js","67ce7405274f633429f10f46136ef376"],["javascript/mode/css/scss.html","06ef3102d764fcb015aa5eaa6727d210"],["javascript/mode/css/scss_test.js","8f025167ac776a13d33ebf7d3ae71033"],["javascript/mode/css/test.js","333dcc51afddfec7fdd8650ffad4b8db"],["javascript/mode/htmlmixed/htmlmixed.js","39d61db7ff97172a9b72d26be49d46ea"],["javascript/mode/htmlmixed/index.html","fa5c7a703eecb2c986d70a369317410e"],["javascript/mode/javascript/index.html","eb50c26d766fb06069e3f717bc6e9863"],["javascript/mode/javascript/javascript.js","6972cec48f1bf4017716711099769c39"],["javascript/mode/javascript/json-ld.html","a1d49489ee5f2c9d4a602a0d4f8ef479"],["javascript/mode/javascript/test.js","e2f67ae8f5de2bfc6013ed368ea0123e"],["javascript/mode/javascript/typescript.html","92e3fd696a6f697c2c7a549473f548e6"],["javascript/mode/python/index.html","2aadb6eb442ace4d1654d3dbe45d0324"],["javascript/mode/python/python.js","f137d8108f89b2c114f42d8c28a504cf"],["javascript/mode/xml/index.html","2f1a86afbed4dfa119d727a04f75c62c"],["javascript/mode/xml/test.js","23de2fff06fb6980d0a778aa0c9a0453"],["javascript/mode/xml/xml.js","aa04cfaea621059ebdd4dde0076e5abc"],["javascript/python_compressed.js","c51935d76613b0a04ee0c97373119f91"],["javascript/reeborg.js","ed8db04a3d0b71a569baf1f85424cc66"],["manifest.json","5240d3693d6c8b6ae24d10acc2426c36"],["maskable_192.png","a9f6b71d91efc95370ecb4ccdee09384"],["package-lock.json","95d3339189ae597afe365cd8c1238396"],["ree_144.png","0e874032febfa4d797bb0c62971a26e8"],["ree_192.png","a522139352913a77ee720e79111b6952"],["ree_512.png","d55f695c95a9121fd5661a47d43c7be6"],["src/images/1.png","68407207d5ccb49b1dc83a164db941a7"],["src/images/2.png","9aedcc27137c7ff29b575e1c872ae98a"],["src/images/3.png","367b18edf522ec7c7054d0b0de276a9b"],["src/images/4.png","19752543ca0f40dd9c1266ceaa079a77"],["src/images/5.png","907d50ccb82f8f70aa462b35ff6ca26f"],["src/images/apple.png","3eac63402d0a366c6f20fa14d1a04e3e"],["src/images/apple_goal.png","278b0200b9dc4fa0bd49d0e950981e20"],["src/images/banana.png","b05d1a08c3d3aee9e416a164babb4026"],["src/images/banana_goal.png","ecf9f619d703438c3b472879118ebe72"],["src/images/beeper0.png","b63ba97b42323656d8a1c97c35856bfe"],["src/images/beeper1.png","e9407936020729e991131bf36aa752bf"],["src/images/beeper2.png","3e385f053da8c7c0fa3cb3ed945fea53"],["src/images/beeper3.png","6179d5806cccec41213a2987d07422ca"],["src/images/beeper_goal.png","b84ba1f3ec0209da6919776d89e57db7"],["src/images/blue_robot_e.png","8faaa83cec82f65553d65dbae1216f5f"],["src/images/blue_robot_n.png","f21d5c9be29e0b1d0e3764defb40ec6e"],["src/images/blue_robot_s.png","4f7fc0bd4de6949ec7409eff9f3c5003"],["src/images/blue_robot_w.png","8db0a0cd51434e995c09033bc4b84e6b"],["src/images/box.png","85309b004539c5eb3384081b4d573126"],["src/images/box_goal.png","d6d880b685215f9351dcadceb749904b"],["src/images/bricks.png","490dc9e841c26f49bf5538f55176b302"],["src/images/bridge.png","1798950b6eb5abc50aaf72ff1e204c73"],["src/images/carrot.png","ac1f9c547e4881032645a5f27eef28d0"],["src/images/carrot_goal.png","830dcf239ef91ab859e10560dfeaed8f"],["src/images/daisy.png","1dfd06f685cb1fa63ba4b4dde2b93c88"],["src/images/daisy_goal.png","ab04ba1ca61aa9fe24744c870c050b10"],["src/images/dandelion.png","bea84b352f1352bf13563467d8fadd51"],["src/images/dandelion_goal.png","f48920f4039d22544130096d400e9d20"],["src/images/desert.jpg","6dd2b4e398ec8be50b8b9e70efd8d0a8"],["src/images/east.png","e5126ba3eba6588b893502e2c148f204"],["src/images/east_border.png","e5126ba3eba6588b893502e2c148f204"],["src/images/east_edit.png","4a831436e2641746de6cfe6e26f1b4de"],["src/images/east_goal.png","d91a52d20602f8969a7e54db721c8e71"],["src/images/east_grid.png","814f4af9f03aedbdab53dbd3d03826a0"],["src/images/external_link.png","05bdb577776720b0cc872154c7c54876"],["src/images/favicon.ico","6a3eb0f3adb2d12bc7131c21967b9ee3"],["src/images/fence_double.png","83aa0ec88b7d72bbd1c9a4a2f84bc5cb"],["src/images/fence_left.png","95b0f5beebaaebaddb381349b77eafc1"],["src/images/fence_right.png","e67688025cd8000aaec5f10fab731309"],["src/images/fence_vertical.png","862b53bb579a5720307c375a6dc6e244"],["src/images/fire.png","57e3ebb702699bd53a05c633410c3a4c"],["src/images/fire1.png","6e48f068162e3332bda00eae55b041f3"],["src/images/fire2.png","cbbc9c4d885c5051ab6e40f78101c560"],["src/images/flame1.png","5006d042bc749eb9a1119851976a39e3"],["src/images/flame2.png","8e7fd858f58343733cd19fa404cdf8c8"],["src/images/flame3.png","b025c9e2e1e190d3ad45d4389087486b"],["src/images/flame4.png","a820e2317b9189a81415630da637307e"],["src/images/flame5.png","319c644c0f56557c032ce4c9d5e3a6ba"],["src/images/flame6.png","15e3a429b52b47780f937582168d11ed"],["src/images/fromage.png","e681602bf4fac2f8faf3df001dd14d1b"],["src/images/grass.png","7c0d72016c220cd2081e7da2909e5f82"],["src/images/grass_bottom_left.png","7a4588716aedd380dbfd0eb009d6c5de"],["src/images/grass_bottom_right.png","0ba7553ac06087adf144e3b1a143c7d3"],["src/images/grass_top_left.png","69c642d15dd4a0a743ec748aa8a5486d"],["src/images/grass_top_right.png","bfc58e82c7568ea7982ef9792f8e483a"],["src/images/gravel.png","5464ffdeba6f8fa1c9f16493ca779869"],["src/images/green_home_tile.png","e654d31dc0ace71b3cac3363f6a7b58c"],["src/images/green_robot_e.png","bd045ff66b66b4c11e0934d250795767"],["src/images/green_robot_n.png","116d6af75c140b39688379846673ee9c"],["src/images/green_robot_s.png","166402224a721e1ec65d7c6546066012"],["src/images/green_robot_w.png","097f046a0f142b4075bcaa65011d78e5"],["src/images/highlight.png","40738b38cf77a5ad86c44f6584e147fa"],["src/images/house.png","484556fc97899b6b4efc3e38f5194d84"],["src/images/hurdles.png","64797606afb2d93b156f498c1f82b36a"],["src/images/ice.png","85a5812f7623a5b9f976e702d710d0ff"],["src/images/leaf.png","da92da6c2e7f27c6216639d3b5cbcb5a"],["src/images/leaf_goal.png","dc1c4001fda285614ee818acb3a9ac18"],["src/images/light_blue_robot_e.png","aea12c6d4cd39ec929c20de2b5a92c08"],["src/images/light_blue_robot_n.png","cc2b0a800a6b7a673e85388bd44aeb64"],["src/images/light_blue_robot_s.png","e45d655f1dee5dbc940fd22cdde07a02"],["src/images/light_blue_robot_w.png","c39202ffc4243239e29f4028ed26799e"],["src/images/logs.png","f04fb187ed0e778375f3b2cced5e3e73"],["src/images/magnifying_no.png","80835e5a7aa07a675195f662434b9c44"],["src/images/magnifying_yes.png","b6f8bfd592f90e21c45f75a3aaa94b1f"],["src/images/mailto.png","1fa8120c057cdc0fdb092b87d8b8e898"],["src/images/mort.png","facebc287d025986629160243741b30d"],["src/images/mud.png","6db1b29848f4dc801b703a616946afd1"],["src/images/north.png","779e2a317679c6f56ee61bb7c11d799c"],["src/images/north_border.png","779e2a317679c6f56ee61bb7c11d799c"],["src/images/north_edit.png","4362e4fc360d9446908f50cd0c4003fa"],["src/images/north_goal.png","9dbedeb4fd3d2e5eec401f37380d29ed"],["src/images/north_grid.png","ac7244ecd5cc720312a809496268410d"],["src/images/not_ok.png","bbd14cb2a4ced04a5b393256a3f16d32"],["src/images/ok.png","c261ca8a188f02fc2f6c5fc1d083a728"],["src/images/open_program.png","95d4a39f4c0d3abebfd97eb93be08b72"],["src/images/orange.png","822297db82e82b8226c71152bc0d973e"],["src/images/orange_goal.png","6962e1edb3c4603b15ed237c7a08f83b"],["src/images/ouch.png","71962d30eacd219bf4d58b14384b46d9"],["src/images/pale_grass.png","69cbbcca976f07758b0be58a05b084f2"],["src/images/pause.png","29da7364f29549013ec904d4f32d8a31"],["src/images/plain_e.png","7ca7d60ac6cd4c4216dfc070ae798a9b"],["src/images/plain_n.png","14ddb125cd07cc59fef3716f111f400a"],["src/images/plain_s.png","30efaf318f847e47b2ef4123618e65f6"],["src/images/plain_w.png","95ba5bf6530358cc5d493f750572eaf4"],["src/images/play.png","5d873a6113508e03d92e51ada35b39ba"],["src/images/poison.png","6b074cf7a5986c72a763d5d03be2b4a0"],["src/images/purple_robot_e.png","1874adc1fc2234a8c5aa89412f4bb52c"],["src/images/purple_robot_n.png","ad255f92d9940cb1c995a9509993d526"],["src/images/purple_robot_s.png","afd4fe08f33e84ce9a9f5bd48bd6f0c4"],["src/images/purple_robot_w.png","d046cd1892c28e0fa7dc8ac2945bfca2"],["src/images/racing_flag.png","d943f898e4b94e68d565296495da4139"],["src/images/rat_e.png","d4af81ee17f5afa8f5d7262bb369e59a"],["src/images/rat_n.png","03bfe3d97b13abe2d5089f26e43ec7bc"],["src/images/rat_s.png","67189ab2e341a7f5fe188e422c598567"],["src/images/rat_w.png","f65bad657aef1c2dd95646477ecc2814"],["src/images/reeborg_judkis.jpg","ef4cd0e1286fd1991b1234686ee958c2"],["src/images/reload.png","5151eeb2daefa1f292c8f57b0b22d6ca"],["src/images/resize.png","4196356a4c839b5b33205d79b2d6d8e6"],["src/images/reverse_step.png","0a0d304a8fb63ead4485199db9985317"],["src/images/robot_e.png","e9597932d9ec4172f8a2a3cfe7099f58"],["src/images/robot_n.png","a08ef2214b1b25fba993d3ec53887303"],["src/images/robot_random.png","baf2395650d3b3ceba07784166f1269f"],["src/images/robot_s.png","f11613d0d9f76e1f925277cb73f41e98"],["src/images/robot_w.png","e8d7f23e6a321bbb1010ad9d912f631f"],["src/images/rover_e.png","3390c4052a1dad6256b9fc09185a7f65"],["src/images/rover_n.png","0d72a7221cc2d694fba31cee665eb9d4"],["src/images/rover_s.png","309e6f6cc034f240f2d2c8f07d82fe6e"],["src/images/rover_w.png","e3130fc7206f9c6161e991627f06a1d3"],["src/images/save_program.png","0fb73a1ab5c622ca0d32ecf02ac81474"],["src/images/scorpion.png","8bc5ad5be3477456f15b601640e0dda9"],["src/images/seed.png","3c87e28cda266fbf37823825b84fa499"],["src/images/simple_path.gif","b91c75cdcf4ff594c1acefd7d4e06a5c"],["src/images/smoke1.png","8d128667025d9e6f05fdf1b0a0295ede"],["src/images/smoke2.png","0b83e67814e15cf67e4450155dc20465"],["src/images/smoke3.png","9c57f2748b4856a3dcde6ad55386fe8b"],["src/images/smoke4.png","8dff2721019f410762da2bb884d42ab8"],["src/images/smoke5.png","1a3e3e9db13e773d53252a65be3935d3"],["src/images/smoke6.png","998ba77318e3e33521e507ba9bfc6676"],["src/images/sp_e.png","dccdbf7dca4cf9d9c16b0b4734dab3fe"],["src/images/sp_n.png","9870dcb45c0a485dd4d896b05fb9b2a2"],["src/images/sp_s.png","e5506a9e6955e7c8d85abed1124198c8"],["src/images/sp_w.png","2309f555a666b590a5eb7591a2a73b80"],["src/images/square.png","54bc75b7b7b1efaf19a7658408b0e304"],["src/images/square_goal.png","cc42e66337dfe1c24a3eb67ee32afc77"],["src/images/stalactite.png","334217d02a8e3c2598ae4d2d33c87fec"],["src/images/stalactite2.png","b09e4f520d5a768b1d7905e26b39a743"],["src/images/star.png","affbe3a2371442c1bd644a34b56d1119"],["src/images/star_goal.png","8e426a5bcb8338bf12191c337d784a9a"],["src/images/step.png","d30e31af758622b79fc898e6315d7f1c"],["src/images/stop.png","f29ea74a04319e968795476920614ae4"],["src/images/strawberry.png","4186a8673595a3f37a938df6e3c614c7"],["src/images/strawberry_goal.png","02f445dcefa212b0cd1d5f9adc5e2a0d"],["src/images/student.jpg","73be4f2b60a2c9e0e0f58598f308fd5a"],["src/images/teleport.png","60cf158e12147b18884767f3e3dcc7cb"],["src/images/tile_colour.png","a2f251017043f078bda009767a49f41f"],["src/images/token.png","5961f0d03c8cf737f28d9f6137c73ebc"],["src/images/token_goal.png","c1e8bf243eb4879a4e13ac9112ce05de"],["src/images/transparent_robot.png","b4caad67e8b3c824baca407d9b087028"],["src/images/transparent_tile.png","ca5c08aaa50773feb87a09b4969bcd70"],["src/images/triangle.png","877e79d23cb68bffe732bc82520c336e"],["src/images/triangle_goal.png","87316a5e06548a632ed70cfcb9fef12e"],["src/images/tulip.png","21c734eae0b2687c5013a6aa74806687"],["src/images/tulip_goal.png","7365cfb233bc75ceaee76fb1314e3437"],["src/images/water.png","395157c00c8493a8c112fe5610bc5583"],["src/images/water2.png","33b1c32c55b477e254c8443dd3577c85"],["src/images/water3.png","01b552a6cce570f15f969130a0d4f247"],["src/images/water4.png","02049985d831a769666ca655fe7ef79d"],["src/images/water5.png","7841bc36a3bd659f2f40a6afc6328492"],["src/images/water6.png","206403ccee4c195890aaab124fd7eae6"],["src/images/water_bucket.png","0e8f5683cd20121c2220182f2a85dfed"],["src/images/yellow_robot_e.png","006163fc1841d7df30e48c100327133a"],["src/images/yellow_robot_n.png","d0ad514e01037d058b8ac435638d10a7"],["src/images/yellow_robot_s.png","aa5e58e68c42059cc82b2502f822b415"],["src/images/yellow_robot_w.png","e5b655ea7ad92ad58f611f2ecc67bb5a"],["src/python/__init__.py","5527939aca3e9e80d5ab3bee47391f0f"],["src/python/biblio.py","5c1074a162a557d8644942d09998d0cb"],["src/python/biblioteca.py","15c1aabc94449f59a4f0cd8e2f7a331f"],["src/python/biblioteka.py","f74f1858e1b137ba9a2dc77f3a946d6e"],["src/python/biblioteka_lt.py","f74f1858e1b137ba9a2dc77f3a946d6e"],["src/python/bibliothek.py","01b364a2a5532f3f84d44646518b587e"],["src/python/breakout.py","df115a6bbf306e379bc34baf37172bec"],["src/python/common.py","1afd30fb335be701658718c75363d916"],["src/python/editeur.py","1e66a5a5d26d334517f6ef6a3cafa2ea"],["src/python/editor.py","ed6e8a4cb9da9d4baa66b082322b059a"],["src/python/extra.py","bed61309aca1fb3ffcc245a8c64439aa"],["src/python/graphics.py","3315abe9a2a285126ce2fb649cc7579a"],["src/python/highlight.py","4a9cf442d5b05f3be7715f9d9a427cdf"],["src/python/import_test.py","580bfc54c17cfcc2516b5600529d889b"],["src/python/init_reeborg.py","e5b1010d716c72b4f42148478c1c5f75"],["src/python/library.py","77a01df0596287ab5c2e1f0bcf829b57"],["src/python/library_ko.py","e4ffab3aac9fd9847e078fa2cd144d27"],["src/python/my_turtle.py","b8283b4f5bab75f5cf46e093de0a715d"],["src/python/preprocess.py","151f19d60172c45fd563c82f7cc9b93c"],["src/python/py_repl.py","44bd5680e97d7d90b01ace02af15a2ea"],["src/python/reeborg_cn.py","79edbd2416cd9c98dd789093f5a5fac9"],["src/python/reeborg_de.py","3bbc7005909e823d94a030bf6ee4e63c"],["src/python/reeborg_decorators.py","eb82b6ebd638ebe1a32f41a8a76edb57"],["src/python/reeborg_en.py","c1cf2d7ddcd281921204f2f9c244baa9"],["src/python/reeborg_fr.py","183533776294281e7e5f299d215f360f"],["src/python/reeborg_ko.py","28e9006d6f4d7de774e346f7b450719d"],["src/python/reeborg_lt.py","59ab62ab6124914e4d400d242c8622a6"],["src/python/reeborg_pl.py","ffd36300df4c60e532553dc6e897aafc"],["src/python/reeborg_pt.py","5c285776afe53749cd9add3a0c1eaa91"],["src/python/repaired_robot.py","d044aa19aa95ee169d3273f43ccae77d"],["src/python/search_tools.py","78f7663690a65732347a2e251761d64c"],["src/python/sokoban.py","0e36f4426c0421b38cce2dea28f0b949"],["src/python/test_highlight.py","f957c4adeba1fdb2324020d97eb38ca5"],["src/python/test_repair.py","87a711bbe02e32f1d2712a6ee8cc884a"],["src/sounds/break.wav","12542733ed88698ddb0930a5b639bc0e"],["src/sounds/brick.wav","18806e86db7609c2e16ed65e299cd571"],["src/sounds/glitch-sound.wav","d3208486f59abe53afb70d9eae420775"],["src/sounds/move.wav","45f889e69b9510db018a5428a5e9a40a"],["src/sounds/paddle.mp3","367d6939f9efbf0bd00f6f1ce5898352"],["src/sounds/paddle.ogg","2f8b9b409343305361ad5b143632249a"],["src/sounds/paddle.wav","200923e357dd75eb2965e64ed4d8dfd6"],["src/sounds/pick.wav","560676a587e861405eeb544df089bd83"],["src/sounds/success.wav","853068a5833a089c688853347dd5242c"],["src/sounds/toc.wav","1060bee73efb24d04f426a0f84907ade"],["src/sounds/tock.mp3","aced94c886f544470c976c6343653742"],["src/sounds/tock.ogg","4576638ce2324dc1d84b82b2e4f572ec"],["src/sounds/tock.wav","05de04d0994ab1561437a28cb147f9e1"],["src/sounds/turn.wav","6193d9c6019072b6673b20a687b9b25f"],["src/sounds/type.wav","6bd5e301c6473f53871a50f5d091dc06"],["style/codemirror.css","222f2543f91f1be9dec56a49277b3619"],["style/fonts/Roboto-Mono-700/LICENSE.txt","d273d63619c9aeaf15cdaf76422c4f87"],["style/fonts/Roboto-Mono-700/Roboto-Mono-700.eot","bc597ea7d6a1b7faa11242d84aa85774"],["style/fonts/Roboto-Mono-700/Roboto-Mono-700.svg","013b8488b7acdd8a0ebf7807c0b9c5d2"],["style/fonts/Roboto-Mono-700/Roboto-Mono-700.ttf","72d09ce5bba05497c0c295fcf3a58458"],["style/fonts/Roboto-Mono-700/Roboto-Mono-700.woff","970bb27720f2119239313c146a877df1"],["style/fonts/Roboto-Mono-700/Roboto-Mono-700.woff2","f210285ffb3ee06d87e5b8907bae7cb3"],["style/images/ui-bg_flat_0_aaaaaa_40x100.png","4e23f7f7ab8c99dac2325ff44a98eedf"],["style/images/ui-bg_flat_0_ffffff_40x100.png","5d5d65cb3596d5677ded38093f799c37"],["style/images/ui-bg_flat_40_09399a_40x100.png","55ab9fe1c311fa6f22e2f4e4ea0155dc"],["style/images/ui-bg_flat_40_224488_40x100.png","cda24694897ee7238de77507bacf6dc5"],["style/images/ui-bg_flat_55_09399a_40x100.png","0ff311a55a8c62d459a76d55c10722c3"],["style/images/ui-bg_highlight-hard_0_c0402a_1x100.png","95af1f1d869b34004479af78e86b83e1"],["style/images/ui-bg_highlight-soft_100_09399a_1x100.png","178b85f4ef63e44f78b9174e0e369ee2"],["style/images/ui-bg_highlight-soft_100_0b3ea2_1x100.png","320df2f11a615eef07201eeee5a1208a"],["style/images/ui-bg_highlight-soft_100_109410_1x100.png","61e1f21dfd2f79e05218a78dbf630387"],["style/images/ui-bg_highlight-soft_100_cccccc_1x100.png","ac669a142f1dfb6bd6a2c3d5857cf20f"],["style/images/ui-bg_highlight-soft_100_ffffff_1x100.png","f3cdc004e560d4ec2a6cd1ac89ebaa3d"],["style/images/ui-icons_09399a_256x240.png","d2a9615d91dd1968e697ed45ab1019f9"],["style/images/ui-icons_109410_256x240.png","5cba537820c11ae3d2af46a03b164360"],["style/images/ui-icons_ffffff_256x240.png","a98c546518c4b7ad5edda8d289714b01"],["style/jquery-ui.custom.min.css","f1c11d66916fd2490549ae6130f3396b"],["style/reeborg_world2.css","ade96333967d6708fbb327d78e73420a"],["task/task.xml","dff76e6f6838daada84f46abe5eb7f63"],["task/tests.xml","e3900c33ee07d03cd19456032808a470"],["worlds/level.json","331f9084acd72755da5464f67aab3ac1"],["worlds/menu.json","91822bce632fcb688d2d84f291de7431"]];
var cacheName = 'sw-precache-v3-sw-precache-' + (self.registration ? self.registration.scope : '');


var ignoreUrlParametersMatching = [/^utm_/];



var addDirectoryIndex = function(originalUrl, index) {
    var url = new URL(originalUrl);
    if (url.pathname.slice(-1) === '/') {
      url.pathname += index;
    }
    return url.toString();
  };

var cleanResponse = function(originalResponse) {
    // If this is not a redirected response, then we don't have to do anything.
    if (!originalResponse.redirected) {
      return Promise.resolve(originalResponse);
    }

    // Firefox 50 and below doesn't support the Response.body stream, so we may
    // need to read the entire body to memory as a Blob.
    var bodyPromise = 'body' in originalResponse ?
      Promise.resolve(originalResponse.body) :
      originalResponse.blob();

    return bodyPromise.then(function(body) {
      // new Response() is happy when passed either a stream or a Blob.
      return new Response(body, {
        headers: originalResponse.headers,
        status: originalResponse.status,
        statusText: originalResponse.statusText
      });
    });
  };

var createCacheKey = function(originalUrl, paramName, paramValue,
                           dontCacheBustUrlsMatching) {
    // Create a new URL object to avoid modifying originalUrl.
    var url = new URL(originalUrl);

    // If dontCacheBustUrlsMatching is not set, or if we don't have a match,
    // then add in the extra cache-busting URL parameter.
    if (!dontCacheBustUrlsMatching ||
        !(url.pathname.match(dontCacheBustUrlsMatching))) {
      url.search += (url.search ? '&' : '') +
        encodeURIComponent(paramName) + '=' + encodeURIComponent(paramValue);
    }

    return url.toString();
  };

var isPathWhitelisted = function(whitelist, absoluteUrlString) {
    // If the whitelist is empty, then consider all URLs to be whitelisted.
    if (whitelist.length === 0) {
      return true;
    }

    // Otherwise compare each path regex to the path of the URL passed in.
    var path = (new URL(absoluteUrlString)).pathname;
    return whitelist.some(function(whitelistedPathRegex) {
      return path.match(whitelistedPathRegex);
    });
  };

var stripIgnoredUrlParameters = function(originalUrl,
    ignoreUrlParametersMatching) {
    var url = new URL(originalUrl);
    // Remove the hash; see https://github.com/GoogleChrome/sw-precache/issues/290
    url.hash = '';

    url.search = url.search.slice(1) // Exclude initial '?'
      .split('&') // Split into an array of 'key=value' strings
      .map(function(kv) {
        return kv.split('='); // Split each 'key=value' string into a [key, value] array
      })
      .filter(function(kv) {
        return ignoreUrlParametersMatching.every(function(ignoredRegex) {
          return !ignoredRegex.test(kv[0]); // Return true iff the key doesn't match any of the regexes.
        });
      })
      .map(function(kv) {
        return kv.join('='); // Join each [key, value] array into a 'key=value' string
      })
      .join('&'); // Join the array of 'key=value' strings into a string with '&' in between each

    return url.toString();
  };


var hashParamName = '_sw-precache';
var urlsToCacheKeys = new Map(
  precacheConfig.map(function(item) {
    var relativeUrl = item[0];
    var hash = item[1];
    var absoluteUrl = new URL(relativeUrl, self.location);
    var cacheKey = createCacheKey(absoluteUrl, hashParamName, hash, false);
    return [absoluteUrl.toString(), cacheKey];
  })
);

function setOfCachedUrls(cache) {
  return cache.keys().then(function(requests) {
    return requests.map(function(request) {
      return request.url;
    });
  }).then(function(urls) {
    return new Set(urls);
  });
}

self.addEventListener('install', function(event) {
  event.waitUntil(
    caches.open(cacheName).then(function(cache) {
      return setOfCachedUrls(cache).then(function(cachedUrls) {
        return Promise.all(
          Array.from(urlsToCacheKeys.values()).map(function(cacheKey) {
            // If we don't have a key matching url in the cache already, add it.
            if (!cachedUrls.has(cacheKey)) {
              var request = new Request(cacheKey, {credentials: 'same-origin'});
              return fetch(request).then(function(response) {
                // Bail out of installation unless we get back a 200 OK for
                // every request.
                if (!response.ok) {
                  throw new Error('Request for ' + cacheKey + ' returned a ' +
                    'response with status ' + response.status);
                }

                return cleanResponse(response).then(function(responseToCache) {
                  return cache.put(cacheKey, responseToCache);
                });
              });
            }
          })
        );
      });
    }).then(function() {
      
      // Force the SW to transition from installing -> active state
      return self.skipWaiting();
      
    })
  );
});

self.addEventListener('activate', function(event) {
  var setOfExpectedUrls = new Set(urlsToCacheKeys.values());

  event.waitUntil(
    caches.open(cacheName).then(function(cache) {
      return cache.keys().then(function(existingRequests) {
        return Promise.all(
          existingRequests.map(function(existingRequest) {
            if (!setOfExpectedUrls.has(existingRequest.url)) {
              return cache.delete(existingRequest);
            }
          })
        );
      });
    }).then(function() {
      
      return self.clients.claim();
      
    })
  );
});


self.addEventListener('fetch', function(event) {
  if (event.request.method === 'GET') {
    // Should we call event.respondWith() inside this fetch event handler?
    // This needs to be determined synchronously, which will give other fetch
    // handlers a chance to handle the request if need be.
    var shouldRespond;

    // First, remove all the ignored parameters and hash fragment, and see if we
    // have that URL in our cache. If so, great! shouldRespond will be true.
    var url = stripIgnoredUrlParameters(event.request.url, ignoreUrlParametersMatching);
    shouldRespond = urlsToCacheKeys.has(url);

    // If shouldRespond is false, check again, this time with 'index.html'
    // (or whatever the directoryIndex option is set to) at the end.
    var directoryIndex = 'index.html';
    if (!shouldRespond && directoryIndex) {
      url = addDirectoryIndex(url, directoryIndex);
      shouldRespond = urlsToCacheKeys.has(url);
    }

    // If shouldRespond is still false, check to see if this is a navigation
    // request, and if so, whether the URL matches navigateFallbackWhitelist.
    var navigateFallback = '';
    if (!shouldRespond &&
        navigateFallback &&
        (event.request.mode === 'navigate') &&
        isPathWhitelisted([], event.request.url)) {
      url = new URL(navigateFallback, self.location).toString();
      shouldRespond = urlsToCacheKeys.has(url);
    }

    // If shouldRespond was set to true at any point, then call
    // event.respondWith(), using the appropriate cache key.
    if (shouldRespond) {
      event.respondWith(
        caches.open(cacheName).then(function(cache) {
          return cache.match(urlsToCacheKeys.get(url)).then(function(response) {
            if (response) {
              return response;
            }
            throw Error('The cached response that was expected is missing.');
          });
        }).catch(function(e) {
          // Fall back to just fetch()ing the request if some unexpected error
          // prevented the cached response from being valid.
          console.warn('Couldn\'t serve response for "%s" from cache: %O', event.request.url, e);
          return fetch(event.request);
        })
      );
    }
  }
});







